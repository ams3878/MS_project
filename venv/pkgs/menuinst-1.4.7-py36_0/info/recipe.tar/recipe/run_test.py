import menuinst

print('menuinst.__version__: %s' % menuinst.__version__)
assert menuinst.__version__ == '1.4.7'
